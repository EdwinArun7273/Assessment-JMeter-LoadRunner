AddToCart()
{

	web_add_header("Accept-Language", 
		"en-GB,en;q=0.9");

	lr_think_time(4);

	web_submit_data("1", 
		"Action=https://demowebshop.tricentis.com/addproducttocart/details/22/1", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/health", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=addtocart_22.EnteredQuantity", "Value=1", ENDITEM, 
		EXTRARES, 
		"Url=/content/images/thumbs/0000131_health-book_47.jpeg", "Referer=https://demowebshop.tricentis.com/health", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/ico-close-notification-bar.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/ajax_loader_large.gif", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		LAST);

	return 0;
}
