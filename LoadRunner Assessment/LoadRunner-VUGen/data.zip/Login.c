Login()
{

	web_add_auto_header("Accept-Language", 
		"en-GB,en;q=0.9");

	web_url("logout", 
		"URL=https://demowebshop.tricentis.com/logout", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://ssl.google-analytics.com/__utm.gif?utmwv=5.7.2&utms=5&utmn=171440281&utmhn=demowebshop.tricentis.com&utmcs=UTF-8&utmsr=1280x800&utmvp=1263x689&utmsc=24-bit&utmul=en-gb&utmje=0&utmfl=-&utmdt=Demo%20Web%20Shop&utmhid=233504823&utmr=0&utmp=%2F&utmht=1765358179868&utmac=UA-6574346-11&utmcc=__utma%3D78382081.1373011359.1765358096.1765358096.1765358096.1%3B%2B__utmz%3D78382081.1765358096.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)%7Cutmcmd%3D(none)%3B&utmjid=&utmu=qAAAAAAAAAAAAAAAAAAAAAAE~", "Referer=https:/"
		"/demowebshop.tricentis.com/", ENDITEM, 
		"Url=https://ssl.google-analytics.com/__utm.gif?utmwv=5.7.2&utms=6&utmn=1541280735&utmhn=demowebshop.tricentis.com&utmcs=UTF-8&utmsr=1280x800&utmvp=1263x689&utmsc=24-bit&utmul=en-gb&utmje=0&utmfl=-&utmdt=Demo%20Web%20Shop.%20Login&utmhid=1603123032&utmr=0&utmp=%2Flogin&utmht=1765358182617&utmac=UA-6574346-11&utmcc=__utma%3D78382081.1373011359.1765358096.1765358096.1765358096.1%3B%2B__utmz%3D78382081.1765358096.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)%7Cutmcmd%3D(none)%3B&utmjid=&utmu="
		"qAAAAAAAAAAAAAAAAAAAAAAE~", "Referer=https://demowebshop.tricentis.com/", ENDITEM, 
		LAST);

	web_link("Log in", 
		"Text=Log in", 
		"Snapshot=t6.inf", 
		LAST);

	web_submit_data("login", 
		"Action=https://demowebshop.tricentis.com/login", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/login", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=Email", "Value=testuser4888@test.com", ENDITEM, 
		"Name=Password", "Value=Pass@word123", ENDITEM, 
		"Name=RememberMe", "Value=false", ENDITEM, 
		EXTRARES, 
		"Url=https://ssl.google-analytics.com/__utm.gif?utmwv=5.7.2&utms=7&utmn=1480654854&utmhn=demowebshop.tricentis.com&utmcs=UTF-8&utmsr=1280x800&utmvp=1263x689&utmsc=24-bit&utmul=en-gb&utmje=0&utmfl=-&utmdt=Demo%20Web%20Shop&utmhid=2087753741&utmr=0&utmp=%2F&utmht=1765358196827&utmac=UA-6574346-11&utmcc=__utma%3D78382081.1373011359.1765358096.1765358096.1765358096.1%3B%2B__utmz%3D78382081.1765358096.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)%7Cutmcmd%3D(none)%3B&utmjid=&utmu=qAAAAAAAAAAAAAAAAAAAAAAE~", "Referer=https"
		"://demowebshop.tricentis.com/", ENDITEM, 
		LAST);

	return 0;
}
