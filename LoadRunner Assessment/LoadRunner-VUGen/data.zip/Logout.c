Logout()
{

	web_add_header("Accept-Language", 
		"en-GB,en;q=0.9");

	web_url("logout_2", 
		"URL=https://demowebshop.tricentis.com/logout", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/health", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://ssl.google-analytics.com/__utm.gif?utmwv=5.7.2&utms=9&utmn=1180702160&utmhn=demowebshop.tricentis.com&utmcs=UTF-8&utmsr=1280x800&utmvp=1263x689&utmsc=24-bit&utmul=en-gb&utmje=0&utmfl=-&utmdt=Demo%20Web%20Shop&utmhid=1809475252&utmr=0&utmp=%2F&utmht=1765358224267&utmac=UA-6574346-11&utmcc=__utma%3D78382081.1373011359.1765358096.1765358096.1765358096.1%3B%2B__utmz%3D78382081.1765358096.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)%7Cutmcmd%3D(none)%3B&utmjid=&utmu=qAAAAAAAAAAAAAAAAAAAAAAE~", "Referer=https"
		"://demowebshop.tricentis.com/", ENDITEM, 
		LAST);

	return 0;
}