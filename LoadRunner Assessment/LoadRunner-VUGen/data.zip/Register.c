Register()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-GB,en;q=0.9");

	web_url("demowebshop.tricentis.com", 
		"URL=https://demowebshop.tricentis.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/Themes/DefaultClean/Content/images/top-menu-divider.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/bullet-right.gif", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/star-x-inactive.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/star-x-active.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/loading.gif", "Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/top-menu-triangle.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=https://ssl.google-analytics.com/ga.js", ENDITEM, 
		"Url=/Content/jquery-ui-themes/smoothness/images/ui-bg_flat_75_ffffff_40x100.png", "Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", ENDITEM, 
		"Url=https://ssl.google-analytics.com/r/__utm.gif?utmwv=5.7.2&utms=1&utmn=1023307114&utmhn=demowebshop.tricentis.com&utmcs=UTF-8&utmsr=1280x800&utmvp=1263x644&utmsc=24-bit&utmul=en-gb&utmje=0&utmfl=-&utmdt=Demo%20Web%20Shop&utmhid=1627416932&utmr=-&utmp=%2F&utmht=1765358096411&utmac=UA-6574346-11&utmcc=__utma%3D78382081.1373011359.1765358096.1765358096.1765358096.1%3B%2B__utmz%3D78382081.1765358096.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)%7Cutmcmd%3D(none)%3B&utmjid=1761224864&utmredir=1&utmu="
		"qAAAAAAAAAAAAAAAAAAAAAAE~", ENDITEM, 
		"Url=/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/bullets.png", "Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", ENDITEM, 
		"Url=/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/arrows.png", "Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", ENDITEM, 
		"Url=https://ssl.google-analytics.com/__utm.gif?utmwv=5.7.2&utms=2&utmn=370643230&utmhn=demowebshop.tricentis.com&utmcs=UTF-8&utmsr=1280x800&utmvp=1263x689&utmsc=24-bit&utmul=en-gb&utmje=0&utmfl=-&utmdt=Demo%20Web%20Shop.%20Register&utmhid=868005996&utmr=0&utmp=%2Fregister&utmht=1765358098678&utmac=UA-6574346-11&utmcc=__utma%3D78382081.1373011359.1765358096.1765358096.1765358096.1%3B%2B__utmz%3D78382081.1765358096.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)%7Cutmcmd%3D(none)%3B&utmjid=&utmu="
		"qAAAAAAAAAAAAAAAAAAAAAAE~", ENDITEM, 
		"Url=https://ssl.google-analytics.com/__utm.gif?utmwv=5.7.2&utms=3&utmn=153887520&utmhn=demowebshop.tricentis.com&utmcs=UTF-8&utmsr=1280x800&utmvp=1263x689&utmsc=24-bit&utmul=en-gb&utmje=0&utmfl=-&utmdt=Demo%20Web%20Shop.%20Register&utmhid=1088385062&utmr=0&utmp=%2Fregisterresult%2F1&utmht=1765358168772&utmac=UA-6574346-11&utmcc=__utma%3D78382081.1373011359.1765358096.1765358096.1765358096.1%3B%2B__utmz%3D78382081.1765358096.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)%7Cutmcmd%3D(none)%3B&utmjid=&"
		"utmu=qAAAAAAAAAAAAAAAAAAAAAAE~", ENDITEM, 
		LAST);

	web_link("Register", 
		"Text=Register", 
		"Snapshot=t2.inf", 
		LAST);

	web_submit_data("register", 
		"Action=https://demowebshop.tricentis.com/register", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/register", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=__RequestVerificationToken", "Value=u7JPBoCrc3g3LKrbQIFu3EoP7g5OH10VtIyhuIDtCwq9ZzshuljYbJa-SWauKfcdK51MFCywGRm51MvGJdDpwblwmVfmXqi843nUrDYQhn41", ENDITEM, 
		"Name=Gender", "Value=M", ENDITEM, 
		"Name=FirstName", "Value=testuser4888fn", ENDITEM, 
		"Name=LastName", "Value=testuser4888ln", ENDITEM, 
		"Name=Email", "Value=testuser4888@test.com", ENDITEM, 
		"Name=Password", "Value=Pass@word123", ENDITEM, 
		"Name=ConfirmPassword", "Value=Pass@word123", ENDITEM, 
		"Name=register-button", "Value=Register", ENDITEM, 
		LAST);

	web_image("Tricentis Demo Web Shop", 
		"Alt=Tricentis Demo Web Shop", 
		"Snapshot=t4.inf", 
		EXTRARES, 
		"Url=https://ssl.google-analytics.com/__utm.gif?utmwv=5.7.2&utms=4&utmn=940764940&utmhn=demowebshop.tricentis.com&utmcs=UTF-8&utmsr=1280x800&utmvp=1263x689&utmsc=24-bit&utmul=en-gb&utmje=0&utmfl=-&utmdt=Demo%20Web%20Shop&utmhid=20045736&utmr=0&utmp=%2F&utmht=1765358173390&utmac=UA-6574346-11&utmcc=__utma%3D78382081.1373011359.1765358096.1765358096.1765358096.1%3B%2B__utmz%3D78382081.1765358096.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)%7Cutmcmd%3D(none)%3B&utmjid=&utmu=qAAAAAAAAAAAAAAAAAAAAAAE~", ENDITEM, 
		LAST);

	return 0;
}
