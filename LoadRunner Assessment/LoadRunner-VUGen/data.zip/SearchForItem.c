SearchForItem()
{

	web_add_auto_header("Accept-Language", 
		"en-GB,en;q=0.9");

	web_url("ajax_loader_small.gif", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/ajax_loader_small.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t8.inf", 
		LAST);

	web_url("searchtermautocomplete", 
		"URL=https://demowebshop.tricentis.com/catalog/searchtermautocomplete?term=book", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../Content/jquery-ui-themes/smoothness/images/ui-bg_glass_75_dadada_1x400.png", "Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", ENDITEM, 
		LAST);

	web_url("health", 
		"URL=https://demowebshop.tricentis.com/health", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://ssl.google-analytics.com/__utm.gif?utmwv=5.7.2&utms=8&utmn=2003463190&utmhn=demowebshop.tricentis.com&utmcs=UTF-8&utmsr=1280x800&utmvp=1263x689&utmsc=24-bit&utmul=en-gb&utmje=0&utmfl=-&utmdt=Demo%20Web%20Shop.%20Health%20Book&utmhid=1089019997&utmr=0&utmp=%2Fhealth&utmht=1765358210323&utmac=UA-6574346-11&utmcc=__utma%3D78382081.1373011359.1765358096.1765358096.1765358096.1%3B%2B__utmz%3D78382081.1765358096.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)%7Cutmcmd%3D(none)%3B&utmjid=&utmu="
		"qAAAAAAAAAAAAAAAAAAAAAAE~", "Referer=https://demowebshop.tricentis.com/", ENDITEM, 
		LAST);

	return 0;
}
